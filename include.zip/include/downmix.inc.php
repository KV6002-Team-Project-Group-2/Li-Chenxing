<?php
/**
 * 防采集混淆字符串
 *
 * @version        $Id: downmix.inc.php 1 
 * @package        DedeCMS.Libraries
 * @copyright      Copyright (c) 2007 - 2010, DesDev, Inc.
 * @license        http://help.dedecms.com/usersguide/license.html
 * @link           http://www.dedecms.com
 */
// 引入小助手
// 本版本的文件暂时仅作一个映射,今后开发直接采用helper('downmix');进行调用
helper('downmix');