<?php   if(!defined('DEDEINC')) exit("Request Error!");

// 为了兼容旧版本文件,这里将函数直接封装到archive小助手中
// 所以这里仅做一个文件引入映射,今后的开发,如果遇到此类函数
// 在开发过程中直接使用helper('archive');即可

helper('archive');